<?php

namespace Drupal\vactory_reminder\Services\Exception;

/**
 * Reminder invalid config ID Exception.
 */
class ReminderConsumerIdNotFoundException extends \Exception {}
